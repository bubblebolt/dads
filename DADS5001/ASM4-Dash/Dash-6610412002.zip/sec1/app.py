from dash import Dash

app = Dash(__name__)
server = app.server